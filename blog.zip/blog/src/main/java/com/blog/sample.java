package com.blog;

public class sample {

}
