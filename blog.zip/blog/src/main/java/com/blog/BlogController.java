package com.blog;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.http.*;
import java.util.*;
import org.springframework.security.core.Authentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.UriComponentsBuilder;

import com.google.gson.Gson;

@RestController
public class BlogController {
	{
		System.out.println("controller");
	}
	public static final List userlist=new LinkedList();
	@Autowired
	BlogService service;

	 @RequestMapping("/blogmain")
	    public ModelAndView getblogmain()
	    {
		 return new ModelAndView("blogmain");
	    }
	 @RequestMapping("/showuser")
	 public @ResponseBody String getuserlist()
	 {
		 
			Gson g=new Gson();
			String str=g.toJson(userlist);
			System.out.println(str);
			return str;
	 }
	@RequestMapping("/")
	public ModelAndView showLogin()
	{
		System.out.println("Login");
		return new ModelAndView("Login");
	}
	@RequestMapping("/Blog")
	public ModelAndView showblog()
	{
		return new ModelAndView("Blog");
	}

	@RequestMapping("/home")
	public ModelAndView showhome(HttpServletRequest req,HttpServletResponse res,Principal p)
	{
	     String name=p.getName();
	 
	
		ModelAndView obj=new ModelAndView("home");
		userlist.add(p.getName());
		obj.addObject("user",name);
		return obj;
	}
	@RequestMapping("/registration")
	public ModelAndView showregistermethod()
	{
		return new ModelAndView("registration");
	}

	
	@RequestMapping("/Calendar")
	public ModelAndView showcalendar()
	{
		return new ModelAndView("Calendar");
	}
	@RequestMapping("/editblog")
	public @ResponseBody String editblogs()
	{

		java.util.List bloglist=service.getAllBlogs();
		Gson g=new Gson();
		String str=g.toJson(bloglist);
		return str;
	}
	@RequestMapping("/edit")
	public ModelAndView editpage()
	{

		return new ModelAndView("edit");
	}

	@ModelAttribute("add")
	public Blog addblog()
	{
		return new Blog();
	}
	
	@ModelAttribute("edit")
	public Blog editblog()
	{
		return new Blog();
	}
	@RequestMapping("/addblog")
	public ModelAndView showaddblog(Principal p)
	{
		userlist.add(p.getName());
		return new ModelAndView("addblog").addObject("username",p.getName());
	}
	@RequestMapping(value="/addblog", method=RequestMethod.POST)
	public @ResponseBody String addMyBlog(@ModelAttribute("add") @Valid Blog b,BindingResult c)
	{
		service.addblog(b);
		return "blog published successfully";
	}
	@RequestMapping(value="/edit", method=RequestMethod.POST)
	public @ResponseBody String editMyBlog(@ModelAttribute("edit") @Valid Blog b,BindingResult c)
	{
		service.editblog(b);
		return "blog published successfully";
	}
	@ModelAttribute("delete")
	public Blog deleteblog()
	{
		return new Blog();
	}
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public ModelAndView getdelete()
	{
		return new ModelAndView("delete");
	}
	@RequestMapping("/addcomment")
	public ModelAndView getcomment()
	{
		return new ModelAndView("addcomment");
	}
	
	@ModelAttribute("addcomment")
	public Comment getComment()
	{
		return new Comment();
	}
	@RequestMapping(value="/addcomment" ,method=RequestMethod.POST)
	public String addComment(@ModelAttribute("addcomment") @Valid Comment  c, BindingResult d)
	{
		     service.addComment(c);
		return "";
	}
	@RequestMapping(value="/delete", method=RequestMethod.POST)
	public @ResponseBody String deleteMyBlog(@ModelAttribute("delete") @Valid Blog b,BindingResult c)
	{
		service.deleteblog(b);
		return "blog deleted successfully";
	}
	@RequestMapping("/room")
	public ModelAndView getroom(Principal p,HttpServletRequest req)
	{
		req.getSession().setAttribute("user", p.getName());
		
		return new ModelAndView("room").addObject("roomuser",p.getName());
	}

	@ModelAttribute("register")
	public USER_AUTHENTICATION getregister()
	{
		return new USER_AUTHENTICATION();
	}
	@RequestMapping(value="/viewblogdata", produces="application/json")
	public @ResponseBody String viewblogdata()
	{

		java.util.List bloglist=service.getAllBlogs();
		Gson g=new Gson();
		String str=g.toJson(bloglist);
		return str;
	}
	@RequestMapping(value="/viewblog")
	public  ModelAndView viewblog()
	{
		
		return new ModelAndView("viewblog");
	}
	
@RequestMapping(value="/registration" ,method=RequestMethod.POST)
public @ResponseBody String registeruser(@ModelAttribute("register") USER_AUTHENTICATION user)
{
	user.setENABLED(true);
	 service.adduser(user);
   USER_AUTHORIZATION ua=new USER_AUTHORIZATION();
   ua.setROLE("ROLE_USER");
   ua.setUSER_ID(user.getUSER_ID());
   service.authorizeuser(ua);
	return "user added successfully";
}
@RequestMapping("/Logout")
public ModelAndView logout(HttpServletRequest req,HttpServletResponse res)
{
	try{
		Authentication auth=SecurityContextHolder.getContext().getAuthentication();
       new SecurityContextLogoutHandler().logout(req, res, auth);
         HttpSession session=req.getSession(false);
         if(session!=null)
         {
         	 session.invalidate();
           System.out.println("session invalidated");
           }
		}
		catch(Exception e)
		{
			System.out.println(e);

		}
        	 ModelAndView obj=new ModelAndView("Login");
		return obj;
}
@RequestMapping(value = "/user/", method = RequestMethod.GET)
public ResponseEntity<List<Blog>> listAllUsers() {
    List<Blog> users = service.getAllBlogs();
    if(users.isEmpty()){
        return new ResponseEntity<List<Blog>>(HttpStatus.NO_CONTENT);//You many decide to return HttpStatus.NOT_FOUND
    }
    return new ResponseEntity<List<Blog>>(users, HttpStatus.OK);
}

/*@RequestMapping(value = "/user/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
public ResponseEntity<Blog> getUser(@PathVariable("id") long id) {
    System.out.println("Fetching User with id " + id);
    User user = service.findById(id);
    if (user == null) {
        System.out.println("User with id " + id + " not found");
        return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
    }
    return new ResponseEntity<User>(user, HttpStatus.OK);
}*/
@RequestMapping(value = "/user/", method = RequestMethod.POST)
public ResponseEntity<Void> createUser(@RequestBody Blog user,    UriComponentsBuilder ucBuilder) {
    System.out.println("Creating User " + user.getUsername());

    

    service.addblog(user);

    HttpHeaders headers = new HttpHeaders();
    headers.setLocation(ucBuilder.path("/user/{id}").buildAndExpand(user.getBlogId()).toUri());
    return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
}
@RequestMapping(value = "/user/{id}", method = RequestMethod.PUT)
public ResponseEntity<Blog> updateUser(@PathVariable("id") long id, @RequestBody Blog user) {
    System.out.println("Updating User " + id);
      
 java.util.List lst=service.getSingleBlog((int) id);
      Blog b=(Blog)lst.get(0);
    if (b==null) {
        System.out.println("User with id " + id + " not found");
        return new ResponseEntity<Blog>(HttpStatus.NOT_FOUND);
    }

   b.setBlogdata(user.getBlogdata());
      
service.editblog(b);
    return new ResponseEntity<Blog>(b, HttpStatus.OK);
}

 
 
//------------------- Delete a User --------------------------------------------------------
  
@RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
public ResponseEntity<Blog> deleteUser(@PathVariable("id") long id) {
    System.out.println("Fetching & Deleting User with id " + id);

    java.util.List lst=service.getSingleBlog((int) id);
    Blog b=(Blog)lst.get(0);
    if (b == null) {
        System.out.println("Unable to delete. User with id " + id + " not found");
        return new ResponseEntity<Blog>(HttpStatus.NOT_FOUND);
    }

  service.deleteblog(b);
    return new ResponseEntity<Blog>(HttpStatus.NO_CONTENT);
}



}
